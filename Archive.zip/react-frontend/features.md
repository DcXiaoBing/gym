# rest of features

## USer

- purchase
- reserve class
  - add / edit / cancel
- reserve training
  - add / edit / cancel

## Coach

- view classes
- view reservations

## Front Desk

- check in a user (minus times)
- update a profile?

## Boss

- view revenue
- manage employee
- manage classes
  - add classes manually
- coach list (add on)

--------------------------------

- classes
  - added by manager
  - user can register/cancel
- training
  - system detact empty slot
    - if there is no reserved training, then this slot is avaliable
  - user can register/cancel
- order
  - buy
