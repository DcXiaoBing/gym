# gym management system

- <https://www.burnfitboston.com/info>

## User module

- Common User
  - User Register
    - user register by email
    - empolyee -> can only be done by someone with authorization
  - Login/Logout
  - reset password through email
  - role base authoriazaiton
    - CEO/Boss
    - Manager
    - personal coach
    - common user

## membership

- purchase
- auto-renew

## training

- personal training
  - need reservation
  - need purchase training count
- public training (published by manager)
  - reserve a seat
  - need purchase ticket or unlimit ticket

## About page

- show pictures of studio
- google map module

## team

- show coach list
  - can jump to coach info page
  - can reserve his courses

## Appointment Module

- Calendar
  - user
    - choose time slots to make appointment / place order
      - reschedule/cancel
        - email notification
    - choose date, list all public courses
  - manager
    - check all appointments
    - hanlde reschedule/cancel request from coach
  - coach
    - check what appointment he has
      - cannot reschedule/cancel
        - can send request to manager for reschedule/cancel

## equipment management

- User can reserve a equipment(sport equipment, locker etc.) online
  - show available count when reserve
- equipment list
  - show all available equipment
- reserve / cancel a locker

## User center

- check appointments
- show bill
- refer a friend?
- leave a advice / complain
- count of personal training

member -> location -> other fucntions, benefits

user
customer service, chat room (for agent and user)
notification for phone
verifcation for phone
