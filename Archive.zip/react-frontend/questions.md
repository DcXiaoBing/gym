# All questions

- auto create admin account?
- What if a user has multiple role, and all roles has different page?
- canlendar -> time check
- sing up page, password confirm
