# issues

- data.sql
  - cannot use hibernate and data.sql both
- propertyname in Dao
