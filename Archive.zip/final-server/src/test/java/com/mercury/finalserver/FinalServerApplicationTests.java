package com.mercury.finalserver;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalServerApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
