package com.mercury.finalserver.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductEffectController {

}
