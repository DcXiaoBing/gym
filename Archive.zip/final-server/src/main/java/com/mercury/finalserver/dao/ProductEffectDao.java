package com.mercury.finalserver.dao;

import com.mercury.finalserver.bean.ProductEffect;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductEffectDao extends JpaRepository<ProductEffect, Long> {
}
