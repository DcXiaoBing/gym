INSERT INTO msi_user_profile(id, type) VALUES (1, 'ROLE_ADMIN'), (2, 'ROLE_COACH'), (3, 'ROLE_CUSTOMER');
